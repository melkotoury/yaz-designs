<?php
define('JOURNAL_IS_ADMIN', true);