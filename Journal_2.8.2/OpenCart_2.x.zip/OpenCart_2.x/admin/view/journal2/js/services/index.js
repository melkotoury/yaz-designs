define([
    './ajax',
    './rest',
    './search',
    './spinner'
], function () { });