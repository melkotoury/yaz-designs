require(['app'], function(app) {
    app.controller('MainController', function($scope){

    });
});
